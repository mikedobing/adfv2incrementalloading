Login-AzureRmAccount

$dataFactoryName = "midoadfv2demo"
$resourceGroupName - "demorg"


Set-AzureRmDataFactoryV2LinkedService -DataFactoryName "midoadfv2demo" -ResourceGroupName "demorg" -Name "SQLLinkedService" -File "C:\adf\SQLSource.json"


Set-AzureRmDataFactoryV2Dataset -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -Name "TargetDataset" -File "C:\adf\TargetTable.json"

Set-AzureRmDataFactoryV2Dataset -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -Name "WatermarkDataset" -File "C:\adf\WatermarkDataset.json"

Set-AzureRmDataFactoryV2Pipeline -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -Name "IncrementalCopyPipeline" -File ".\IncrementalCopyPipeline.json"

Set-AzureRmDataFactoryV2Pipeline -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -Name "mainPipeline" -File "C:\adf\mainPipeline.json"

$RunId = Invoke-AzureRmDataFactoryV2Pipeline -PipelineName "mainPipeline" -ResourceGroup $resourceGroupName -dataFactoryName $dataFactoryName