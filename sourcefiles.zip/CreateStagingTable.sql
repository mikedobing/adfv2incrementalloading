CREATE TABLE [SalesLT].[SalesOrderDetail_Staging](
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal] [money] NULL,
	[rowguid] [uniqueidentifier] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	[ExtractDate] [datetime] NULL
)

GO

ALTER TABLE [SalesLT].[SalesOrderDetail_Staging] ADD  DEFAULT (getdate()) FOR [ExtractDate]
GO


